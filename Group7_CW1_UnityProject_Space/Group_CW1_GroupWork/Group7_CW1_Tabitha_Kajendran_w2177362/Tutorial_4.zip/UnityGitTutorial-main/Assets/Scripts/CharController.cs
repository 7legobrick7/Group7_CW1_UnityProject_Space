using UnityEngine;
using UnityEngine.InputSystem;

public class CharController : MonoBehaviour
{
   public float speed = 5f;
   public float rotationSpeed = 100f;

   void Update()
   {

        if (Keyboard.current.upArrowKey.isPressed)
        {
            transform.Translate(Vector3.forward * speed * Time.deltaTime);
        }
        if (Keyboard.current.downArrowKey.isPressed)
        {
            transform.Translate(Vector3.back * speed * Time.deltaTime);
        }

        

        if (Keyboard.current.leftArrowKey.isPressed)
        {
            transform.Rotate(Vector3.up * -rotationSpeed * Time.deltaTime);
        }
        if (Keyboard.current.rightArrowKey.isPressed)
        {
            transform.Rotate(Vector3.up * rotationSpeed * Time.deltaTime);
        }
   }

}
